
public class VegBurger extends VegItems {
	
	public VegBurger(Integer productPrice) {
		super(productPrice,"Veg Burger");
	}
	
}
