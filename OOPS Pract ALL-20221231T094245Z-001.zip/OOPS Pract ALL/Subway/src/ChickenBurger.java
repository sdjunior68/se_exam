
public class ChickenBurger extends NonVegItems {

	public ChickenBurger(Integer productPrice) {
		super(productPrice,"Chicken Burger");
	}

}
