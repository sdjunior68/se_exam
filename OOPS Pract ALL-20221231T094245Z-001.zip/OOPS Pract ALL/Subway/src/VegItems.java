
public abstract class VegItems extends Snack {

	public VegItems(Integer productPrice,String productName) {
		super(productPrice,"VEG",productName);
	}
}
