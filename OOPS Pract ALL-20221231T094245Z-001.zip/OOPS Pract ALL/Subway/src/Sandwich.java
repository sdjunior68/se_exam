
public class Sandwich extends VegItems {
	
	public Sandwich(Integer productPrice) {
		super(productPrice,"Sandwich");
	}
	
	
}
