package foodCourt;

public class ChickenSandwich extends NonVegItems {
	
	public ChickenSandwich(Integer productPrice) {
		super(productPrice,"Chicken Sandwich");
	}
	
}
