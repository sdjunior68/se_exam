package foodCourt;

public class Shawarma extends NonVegItems {
	
	public Shawarma(Integer productPrice) {
		super(productPrice,"Shawarma");
	}
	
}
