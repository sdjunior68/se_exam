package foodCourt;

public class VadaPav extends VegItems {

	public VadaPav(Integer productPrice) {
		super(productPrice,"Vada Pav");
	}

	
}
