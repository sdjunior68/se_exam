package Game;

public class GuardPlayer extends Player{

	public GuardPlayer(String name, Integer jersyNum) {
		super(name, jersyNum);
		// TODO Auto-generated constructor stub
	}

}
