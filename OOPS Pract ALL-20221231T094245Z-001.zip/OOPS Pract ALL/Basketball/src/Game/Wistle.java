package Game;

public class Wistle {
	String color;
	String companyName;

	public Wistle(String color, String companyName) {
		this.color = color;
		this.companyName = companyName;
	}

}
