package Game;

public class Scorekeeper extends Refree {

	public Scorekeeper(String name, Wistle wistle) {
		super(name, wistle);
		// TODO Auto-generated constructor stub
	}

}
