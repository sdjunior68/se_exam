package Game;

public class FoulCondition extends Rule {

}
