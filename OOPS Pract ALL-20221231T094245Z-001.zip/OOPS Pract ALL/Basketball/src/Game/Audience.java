package Game;

public class Audience {
	Integer attendance;
	
	public Audience(Integer attendance) {
		this.attendance = attendance;
	}
	
	public Integer getAttendance() {
		return attendance;
	}

	public void setAttendance(Integer attendance) {
		this.attendance = attendance;
	}

}
