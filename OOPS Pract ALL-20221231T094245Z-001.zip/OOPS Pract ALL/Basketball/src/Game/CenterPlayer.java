package Game;

public class CenterPlayer extends Player {

	public CenterPlayer(String name, Integer jersyNum) {
		super(name, jersyNum);
		// TODO Auto-generated constructor stub
	}
	
}
