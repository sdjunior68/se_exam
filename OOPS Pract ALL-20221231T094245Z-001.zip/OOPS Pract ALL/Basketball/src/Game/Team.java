package Game;

public class Team {
	Player players[];
	Coach coaches[];
	Jersy jersy;
	
	public Team(Player[] players, Coach[] coaches, Jersy jersy) {
		this.players = players;
		this.coaches = coaches;
		this.jersy = jersy;
	}
	
	
}
