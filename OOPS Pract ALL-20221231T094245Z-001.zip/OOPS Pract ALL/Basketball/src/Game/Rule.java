package Game;

public class Rule {

}
