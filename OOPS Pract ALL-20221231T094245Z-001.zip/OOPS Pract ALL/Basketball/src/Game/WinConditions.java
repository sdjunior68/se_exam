package Game;

public class WinConditions extends Rule {
	void checkScore(Score s) {
		
	}
}
