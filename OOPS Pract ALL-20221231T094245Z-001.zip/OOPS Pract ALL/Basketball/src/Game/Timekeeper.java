package Game;

public class Timekeeper extends Refree {

	public Timekeeper(String name, Wistle wistle) {
		super(name, wistle);
		// TODO Auto-generated constructor stub
	}

}
