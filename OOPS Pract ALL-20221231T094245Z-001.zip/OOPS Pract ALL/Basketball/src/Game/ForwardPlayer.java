package Game;

public class ForwardPlayer extends Player {

	public ForwardPlayer(String name, Integer jersyNum) {
		super(name, jersyNum);
		// TODO Auto-generated constructor stub
	}

}
