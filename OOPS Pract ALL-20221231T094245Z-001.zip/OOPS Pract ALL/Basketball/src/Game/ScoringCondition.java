package Game;

public class ScoringCondition extends Rule {
	
}
