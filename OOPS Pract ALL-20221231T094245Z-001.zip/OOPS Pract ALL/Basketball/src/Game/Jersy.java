package Game;

public class Jersy {
	String jersyColor;

	public Jersy(String jersyColor) {
		super();
		this.jersyColor = jersyColor;
	}

	public String getJersyColor() {
		return jersyColor;
	}

	public void setJersyColor(String jersyColor) {
		this.jersyColor = jersyColor;
	}
	
}
