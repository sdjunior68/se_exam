package Game;

public class BasketBallGame {
	Match matches[];
	Rule rules[];
	public BasketBallGame(Match[] matches, Rule rules[]) {
		super();
		this.matches = matches;
		this.rules = rules;
	}
}
