package Game;

public class Refree {
	String name;
	Wistle wistle;
	
	public Refree(String name, Wistle wistle) {
		this.name = name;
		this.wistle = wistle;
	}
	
	void blows(Wistle wistle) {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
