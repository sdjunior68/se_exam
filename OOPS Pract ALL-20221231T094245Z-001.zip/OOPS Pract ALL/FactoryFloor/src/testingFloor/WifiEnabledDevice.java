package testingFloor;

public interface WifiEnabledDevice {
	
	public void enableWifi();
}
