package testingFloor;

public class Buld extends HomeAppliance {

	public Buld() {
		super("Bulb",false);
	}
	
	public Buld(String brand) {
		super("Bulb",false,brand);
	}
}
