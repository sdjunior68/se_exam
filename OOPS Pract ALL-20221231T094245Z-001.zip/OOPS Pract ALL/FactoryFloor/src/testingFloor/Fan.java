package testingFloor;

public class Fan extends HomeAppliance {	
	public Fan() {
		super("Fan",false);
	}
	public Fan(String brand) {
		super("Fan",false);
	}
}
