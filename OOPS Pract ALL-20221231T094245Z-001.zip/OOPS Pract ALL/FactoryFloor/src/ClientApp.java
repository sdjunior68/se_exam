import java.util.ArrayList;

public class ClientApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
