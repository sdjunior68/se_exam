package clientApp;

import testSystem.Vehicle;
import testSystem.Car;
import testSystem.PickupTruck;

public class ClientApp {
	public static void main(String[] args) {
		
		Vehicle a = new Vehicle(); 
		a.start();
		a.stop();

		Car b = new Car(); 
		b.start();
		b.stop();
		
		PickupTruck c = new PickupTruck();
		c.start();
	}
}
