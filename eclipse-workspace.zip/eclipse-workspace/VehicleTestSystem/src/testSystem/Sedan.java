package testSystem;

public class Sedan extends Car implements Electric{
	public Sedan() {
		super();
		
	}
	
	public Boolean checkbattey() {
		System.out.println("Checking battery...");
		return true;
	}
}
