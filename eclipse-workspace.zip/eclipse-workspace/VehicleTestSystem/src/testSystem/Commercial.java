package testSystem;

public interface Commercial {
	public String engine ="V8";
}
