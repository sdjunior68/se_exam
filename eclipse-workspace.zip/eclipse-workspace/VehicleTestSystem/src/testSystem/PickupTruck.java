package testSystem;

public class PickupTruck extends Car implements Commercial{
	public PickupTruck() {
		super();
		
		System.out.println("Engine: "+this.engine);
	}

}
