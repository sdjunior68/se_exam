package testSystem;

public class Vehicle {
	public Vehicle() {
		super();		
	}
	
	public void start(){
		System.out.println("Starting the vehicle");
	}
	
	public void stop(){
		System.out.println("Stopping the vehicle");
	}
}