package testSystem;

public class Car extends Vehicle{
	public Car() {
		super();
	
	}
	
	@Override
	public void start(){
		System.out.println("Starting the car");
	}
	public void stop(){
		System.out.println("Stopping the car");
	}
	
	public void openTrunk(){
		System.out.println("Starting the car");
	}
}
