package testSystem;

public interface Electric {
	public Integer Capacity = 18000;
	
	public Boolean checkbattery();
}