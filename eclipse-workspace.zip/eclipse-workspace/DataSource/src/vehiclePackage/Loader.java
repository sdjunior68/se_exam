package vehiclePackage;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Loader {
	public static List<Vehicle> LoadFile(String filename){
//	public static Boolean LoadFile(String filename){
		Scanner in;
		File input;
		Boolean fileOpened = false;
		List<Vehicle> VehicleList = new ArrayList<>();
		
		try {
			input = new File(filename);
			in = new Scanner(input);
			
//			FileWriter writer = new FileWriter("./output.txt");	
//			while (in.hasNextLine()) {
//				String[] values = in.next().split(",");
//				writer.write("Brand="+values[0]+", Model="+values[1]+"\n");
//			}
//			writer.close();
			while (in.hasNext()) {
				VehicleList.add(new Vehicle(in.next()));
			}
			fileOpened = true;

			if(fileOpened) {
				FileWriter writer = new FileWriter("./output.txt");	
				for (int i=0; i<VehicleList.size(); i++ ) {
					writer.write("Brand="+VehicleList.get(i).getBrand()+", Model="+VehicleList.get(i).getModel()+"\n");
				}
				writer.close();
			}
		}
		catch(Exception e) { System.out.println(e); }

		
//		return null;
//		return fileOpened;
		return VehicleList;
	}
}
