package vehiclePackage;

public class Vehicle {
	private String brand, model;
	
	public Vehicle(String line) {
		String[] values=line.split(",");
		
		this.brand = values[0];
		this.model = values[1];
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String name) {
		this.brand = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
}
