package clientApp;
import vehiclePackage.Loader;

public class ClientApp {
	public static void main(String[] args) {
		System.out.println(Loader.LoadFile("./Input.txt"));	
	}
}