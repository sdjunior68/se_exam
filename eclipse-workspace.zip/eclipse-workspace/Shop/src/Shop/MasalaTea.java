package Shop;

public class MasalaTea extends Tea{

	public MasalaTea(String Cust, Integer Size) {
		this.setVolume(Size);
		this.setName("Masala Tea");
		this.setCust_Name(Cust);
		System.out.println("Masale Tea");
	}
}
