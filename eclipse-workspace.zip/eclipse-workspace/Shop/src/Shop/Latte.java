package Shop;

public class Latte extends Coffee{
	public Latte(String Cust, Integer Size) {
		this.setVolume(Size);
		this.setName("Latte");
		this.setCust_Name(Cust);
		System.out.println("latte");
	}
}
