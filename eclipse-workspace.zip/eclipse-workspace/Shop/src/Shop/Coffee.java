package Shop;

abstract class Coffee extends Beverage {
	public Coffee() {
		this.setType("Coffee");
		System.out.print("Customer Ordered a coffee: ");
	}
}
