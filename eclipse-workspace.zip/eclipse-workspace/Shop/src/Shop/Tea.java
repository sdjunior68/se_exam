package Shop;

abstract class Tea extends Beverage {
	public Tea() {
		this.setType("Tea");

		System.out.print("Customer ordered a tea: ");
	}

}
