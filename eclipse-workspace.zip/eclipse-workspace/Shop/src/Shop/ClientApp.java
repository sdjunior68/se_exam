package Shop;

public class ClientApp {

	public static void main(String[] args) {
	
		// input format: beverage(customerName, size), Note: customerName is string, size: int
		// flow: customer goes to a shop, later orders a beverage 
		
//		Beverage B1 = new Latte("Jon", 1);
//		Beverage B2 = new MasalaTea("Doe", 2);
//		
//		System.out.println("Name: "+B1.getCust_Name()+", Ordered: "+B1.getName()+", Type: "+B1.getType()+", Size: " + B1.getVolume());
//		System.out.println("Name: "+B2.getCust_Name()+", Ordered: "+B2.getName()+", Type: "+B2.getType()+", Size: " + B2.getVolume());
		
		Shop Starbucks = new Shop("Starbucks", "Panjim");
		
//		System.out.println(Starbucks.getName());
	}

}
