package Shop;

 abstract class Beverage {
	 
	private Integer Size;
	private String Type;
	private String Name;
	private String Cust_Name;
	
	public Beverage() {
//		System.out.println(Name +" has been requested");
	}

	public Integer getVolume() {
		return Size;
	}

	public void setVolume(Integer size) {
		Size = size;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}
	public String getCust_Name() {
		return Cust_Name;
	}
	
	public void setCust_Name(String name) {
		Cust_Name = name;
	}
}
