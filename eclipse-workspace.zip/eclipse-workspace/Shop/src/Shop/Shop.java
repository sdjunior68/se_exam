package Shop;

public class Shop {
	private String Name, Location;
	
	public Shop (String name, String location) {
		this.Name = name;
		this.Location = location;
		System.out.println("Customer entered "+this.Name+" in "+this.Location);
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	Beverage B1 = new Latte("Jon", 1);
	Beverage B2 = new MasalaTea("Doe", 2);

//	System.out.println("Name: "+B1.getCust_Name()+", Ordered: "+B1.getName()+", Type: "+B1.getType()+", Size: " + B1.getVolume());
//	System.out.println("Name: "+B2.getCust_Name()+", Ordered: "+B2.getName()+", Type: "+B2.getType()+", Size: " + B2.getVolume());
//	
}
