package clientApp;

import queueImp.*;

public class ClientApp {

	public static void main(String[] args) {
		QueueI list1 = new QueueI();
		list1.setisExitLeft(true);
		list1.enqueue(2);
		list1.enqueue(4);
		list1.enqueue(5);
		list1.enqueue(8);
		list1.list();
		list1.dequeue();
		list1.dequeue();
		list1.list();
		
		QueueI list2 = new QueueI();
		list2.setisExitLeft(false);
		list2.enqueue(3);
		list2.enqueue(4);
		list2.enqueue(7);
		list2.enqueue(8);
		list2.list();
		list2.dequeue();
		list2.dequeue();
		list2.dequeue();
		list2.list();
		
	}
}
