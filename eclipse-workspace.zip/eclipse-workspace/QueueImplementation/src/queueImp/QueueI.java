package queueImp;

import linkedList.LinkedListImplementation;

public class QueueI {
	LinkedListImplementation Queue = new LinkedListImplementation(); 
	private Boolean isExitLeft;
	
	public Boolean getisExitLeft() {
		return isExitLeft;
	}

	public void setisExitLeft(Boolean isExitLeft) {
		this.isExitLeft = isExitLeft;
	}

	public void enqueue(Integer value){
		if (isExitLeft)
			Queue.insertAtEnd(value);
		else
			Queue.insertAtStart(value);
	}
	
	public void dequeue(){
		if (isExitLeft)
			Queue.deleteAtStart();
		else
			Queue.deleteAtEnd();
			
	}
	
	public void seek() {
		
	}
	
	public void list() {
		if (isExitLeft)
			Queue.printFromStart();
		else
			Queue.printFromEnd();
	}	
}
