package linkedList;

public class LLNode {
	private Integer val;
	private LLNode next;
	
	public LLNode(Integer val) {
		super();
		this.val = val;
		this.next = null;
	}

	public Integer getVal() {
		return val;
	}

	public void setVal(Integer val) {
		this.val = val;
	}

	public LLNode getNext() {
		return next;
	}

	public void setNext(LLNode next) {
		this.next = next;
	}
}
