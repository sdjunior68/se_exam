package linkedList;

public class LinkedListImplementation {
	
	LLNode head = null, current = null; //current should be local
	
	public void insertAtStart(int value) {
		LLNode newNode = new LLNode(value);
		if (head == null) {
			head = newNode;
			current = head;
		}
		else {
			newNode.setNext(current);
			current = newNode;
		}
	}
	
	public void insertAtEnd(int value) {
		LLNode newNode = new LLNode(value);
		if (head == null) {
			head = newNode;
			current = head;
		}
		else {
			current.setNext(newNode);
			current = current.getNext();
		}
	}
	
	public void deleteAtStart() {
		if (head == null)
			System.out.println("Queue is empty!");
		else
			head = head.getNext();
	}
	
	public void deleteAtEnd() {
		if (head == null)
			System.out.println("Queue is empty!");
		else {
			LLNode tempPtr = current;
			while (tempPtr.getNext() != head)
				tempPtr = tempPtr.getNext();
			head = tempPtr;
		}
	}
	
	public void printFromStart() {
		LLNode hptr = head;
		while (hptr != null) {
			System.out.print(hptr.getVal());
			if (hptr.getNext() != null)
				System.out.print(", ");
			hptr = hptr.getNext();
		}
		System.out.println();
	}
	
	public void printFromEnd() {
		LLNode cptr = current;
		while (cptr != null) {
			 System.out.print(cptr.getVal());
			if (cptr.getNext() != null)
				System.out.print(", ");
			cptr = cptr.getNext();
		}
		System.out.println();
	}
	
}
