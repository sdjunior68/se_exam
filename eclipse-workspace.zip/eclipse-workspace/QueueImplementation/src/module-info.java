/**
 * 
 */
/**
 * @author Charlton
 *
 */
module QueueImplementation {
}