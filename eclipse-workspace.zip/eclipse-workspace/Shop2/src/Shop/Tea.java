package Shop;

abstract class Tea extends Beverage {
	public Tea() {
		this.setType("Tea");
//		System.out.print("An order for a ");
	}

}
