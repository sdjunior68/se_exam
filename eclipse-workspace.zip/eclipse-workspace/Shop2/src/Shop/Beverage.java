package Shop;

 abstract class Beverage {
	 
	private String Size, Type, Name;
	
	public Beverage() {
//		System.out.println(Name +" has been requested");
	}

	public String getVolume() {
		return Size;
	}

	public void setVolume(Integer size) {
		switch (size) {
		case 1:
			Size = "120 ml";
			break;
		case 2:
			Size = "150 ml";
			break;
		case 3:
			Size = "200 ml";
			break;

		default:
			Size = "100 ml";
			break;
		}
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}
}
