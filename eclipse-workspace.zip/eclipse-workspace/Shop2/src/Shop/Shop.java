package Shop;

import java.util.ArrayList;


public class Shop {
	private String Name, Location, Cust_Name;
	
	public Shop (String cust_name,String name, String location) {
		this.Cust_Name = cust_name;
		this.Name = name;
		this.Location = location;
		System.out.println("\n"+ this.Cust_Name +" entered "+ this.Name +" in " +this.Location);
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	public String getCust_Name() {
		return Cust_Name;
	}
	
	public void setCust_Name(String name) {
		Cust_Name = name;
	}
	
	
	ArrayList<Beverage> orders = new ArrayList<>();
	
	public void order_beverages(ArrayList<String> beverages) {
		System.out.println(this.Cust_Name +" ordered: ");
//		for (int i=0; i < beverages.size(); i++) {
//			System.out.print(beverages.get(i)+" ");
//		}
		for (String beverage : beverages) {
			switch (beverage) {
			case "Latte":
				orders.add(new Latte(this.Cust_Name,1));
				break;
				
			case "Masala Tea":
				orders.add(new MasalaTea(this.Cust_Name,1));
				break;
	
			default:
				System.out.println(beverage +" is unavailable or order isn't clear");
				break;
			}
		}
	}
	
	public void order_a_beverage(String beverage, Integer size) {
		switch (beverage) {
		case "Latte":
			orders.add(new Latte(this.Cust_Name,size));
//			new Latte(this.Cust_Name,size);
			break;
			
		case "Masala Tea":
			orders.add(new MasalaTea(this.Cust_Name,size));
//			new MasalaTea(this.Cust_Name,size);
			break;

		default:
			System.out.println(this.Cust_Name +"'s was not on the menu");
			break;
		}
	}
	
	
	public void list_orders() {
		System.out.println("\nOrders placed by "+ this.Cust_Name +" in "+ this.Name +"(" +this.Location +"): "+orders.size());
		for (int i=0; i < orders.size(); i++)
			System.out.println((i+1) +") "+ orders.get(i).getName() +", volume: "+orders.get(i).getVolume());
	}
}
