package Shop;

public class Latte extends Coffee{
	public Latte(String cName, Integer Size) {
		this.setVolume(Size);
		this.setName("Latte");
		System.out.println("Latte volume: "+ this.getVolume() );
//		+" has been placed by "+cName);
	}
}
