package Shop;

public class MasalaTea extends Tea{

	public MasalaTea(String cName, Integer Size) {
		this.setVolume(Size);
		this.setName("Masala Tea");
		System.out.println("Masala Tea volume "+ this.getVolume() );
//		+" has been placed by "+cName);
	}
}
