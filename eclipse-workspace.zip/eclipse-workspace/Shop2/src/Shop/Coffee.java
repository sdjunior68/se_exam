package Shop;

abstract class Coffee extends Beverage {
	public Coffee() {
		this.setType("Coffee");
//		System.out.print("An order for a ");
	}
}
