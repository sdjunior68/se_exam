package Shop;

import java.util.ArrayList;

public class ClientApp {

	public static void main(String[] args) {
	
		// flow: customer goes to a shop and orders a beverage 
		// need to take multiple orders and return the list of beverages ordered
		
		// input format: shop(customer_name, shopName, location)
		//Note: customer_name, shopName, location is a string
		
		// input format: beverage(ItemName, size), 
		// Note: ItemName is string & size is int ()
		// options: ItemNames ["Latte","Masala Tea"]
		
//		Shop Starbucks = new Shop("John","Starbucks", "Panjim");
//		
//		Starbucks.order_a_beverage("Latte", 1);
//		Starbucks.order_a_beverage("Masala Tea", 3);
		
//		Starbucks.list_orders();
//
//		Shop TeaCorner = new Shop("Martin", "TeaCorner", "Margao");
//		TeaCorner.order_a_beverage("Latte", 1);
//		TeaCorner.order_a_beverage("Masala Tea", 4);
//		
//		Starbucks.order_a_beverage("Latte", 2);
//		
//		TeaCorner.order_a_beverage("Latte", 1);
//		TeaCorner.order_a_beverage("Water", 2);
//		
//		Starbucks.list_orders();				
//		
//		TeaCorner.list_orders();
//		
		Shop test = new Shop("Sam", "TeaPot", "Margao");
		
		ArrayList<String> orders= new ArrayList<>();
		orders.add("Latte");
		orders.add("Tea");
		orders.add("Latte");
		
		test.order_beverages(orders);
		
	}

}
