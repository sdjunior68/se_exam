/**
 * 
 */
/**
 * @author Charlton
 *
 */
module BikeInfo {
}