package clientApp;

import infoSystem.*;
import java.util.HashMap;
import java.util.Map;

public class ClientApp {

	public static void main(String[] args) {
		Map<String, Car> cars = new HashMap<String, Car>();
		cars.put("a", new Car("Hundai", "Santro", 1200000, 1000, FuelType.Petrol, GearShift.Manual));
		cars.put("b", new Car("Maruti", "Alto", 700000, 800, FuelType.Hybrid, GearShift.Auto));
		cars.put("c", new Car("Audi", "A6", 22000000, 5000, FuelType.Diesel, GearShift.Manual));
		
//		System.out.println(cars);
		
		Info test = new Info();
		test.listByBrand(cars, "Hundai");
		 
	}
}
