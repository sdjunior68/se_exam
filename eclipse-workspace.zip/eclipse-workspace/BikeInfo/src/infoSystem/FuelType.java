package infoSystem;

public enum FuelType {
	Petrol, 
	Diesel, 
	CNG, 
	Hybrid 
}
