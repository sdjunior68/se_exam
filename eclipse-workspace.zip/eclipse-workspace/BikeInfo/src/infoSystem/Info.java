package infoSystem;

import java.util.Map;

public class Info {
	

 cars;

	public Info() {
		
	}
	
	
	public Map<String, Car> listAll(Map<String, Car> cars) {
		
		return cars; 
	}

	public Map<String, Car> listByBrand(Map<String, Car> car, String brand) {
		for (String key : car.keySet()) {
			if (car.get(key).getBrand() == brand) {
				System.out.println(car.get(key).getBrand() +" "+ car.get(key).getModel());
				
			}			
		}
		return car; 
	}
}
