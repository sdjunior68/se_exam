package infoSystem;

public enum GearShift {
	Auto,
	Manual
}
