package infoSystem;

public class Car {
	private String brand, model;
	private Integer price, displacement;
	private FuelType fuel;
	private GearShift gear;

	
	
	public String getBrand() { return brand; }
	
	public void setBrand(String brand) { this.brand = brand; }

	
	
	public String getModel() { return model; }

	public void setModel(String model) { this.model = model; }

	
	
	public Integer getPrice() { return price; }

	public void setPrice(Integer price) { this.price = price; }

	
	
	public Integer getDisplacement() { return displacement; }

	public void setDisplacement(Integer displacement) { this.displacement = displacement; }
	
	
	
	public FuelType getFuel() { return fuel; }

	public void setFuel(FuelType fuel) { this.fuel = fuel; }
	
	
	
	public GearShift getGear() { return gear; }

	public void setGear(GearShift gear) { this.gear = gear; }

	
	
	public Car(String brand, String model, Integer price, Integer displacement, FuelType fuel, GearShift gear) {
		this.brand = brand; 
		this.model = model;
		this.price = displacement; 
		this.displacement = displacement;
		this.fuel = fuel;
		this.gear = gear;
	}
}
